
import React from 'react';

export interface SlideDefinition {
  id: string;
  content: React.ReactNode;
  className?: string; // Additional classes for the slide container itself
  style?: React.CSSProperties; // Additional inline styles for the slide container
}
