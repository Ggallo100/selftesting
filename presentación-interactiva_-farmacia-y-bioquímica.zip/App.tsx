
import React, { useState, useCallback } from 'react';
import type { SlideDefinition } from './types';

const slidesData: SlideDefinition[] = [
  {
    id: 'slide-1',
    className: 'text-white bg-blend-overlay bg-[#2c3e50]/70',
    style: { backgroundImage: "url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')" },
    content: (
      <>
        <h1 className="text-[2.8rem] text-[#F39C12] mb-2.5 font-bold">IDENTIDAD PROFESIONAL EN FARMACIA Y BIOQUÍMICA</h1>
        <h2 className="text-[2rem] text-white mb-6 font-semibold">Conquistando el Sector Clínico y Hospitalario del Futuro</h2>
      </>
    ),
  },
  {
    id: 'slide-2',
    content: (
      <>
        <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">¿Qué Descubriremos Hoy?</h2>
        <ul className="text-center list-none p-0">
            <li className="py-1.25"><strong className="text-lg">Parte 1:</strong> Fundamentos del Rol (Funciones, Áreas, Salarios)</li>
            <li className="py-1.25"><strong className="text-lg">Parte 2:</strong> Visión Estratégica y Futuro de la Profesión</li>
            <li className="py-1.25"><strong className="text-lg">Parte 3:</strong> Tu Desarrollo y Línea de Carrera</li>
        </ul>
      </>
    ),
  },
  {
    id: 'slide-3',
    content: (
      <>
        <h2 className="text-[2rem] text-[#2c3e50] mb-5 font-semibold">Tu Misión Esencial: Funciones Clave</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 w-full max-w-4xl">
            {[
                { icon: '💊', title: 'Dispensación y Cuidado', description: 'Supervisar el expendio, orientar al paciente y asegurar el uso adecuado de medicamentos.' },
                { icon: '📦', title: 'Gestión y Logística', description: 'Almacenar y custodiar productos garantizando su conservación, estabilidad y calidad.' },
                { icon: '🔬', title: 'Calidad y Preparados', description: 'Elaborar preparados farmacéuticos y verificar que no existan productos no conformes.' },
                { icon: '🔔', title: 'Vigilancia y Capacitación', description: 'Liderar la Farmacovigilancia y entrenar permanentemente al personal técnico y asistente.' },
            ].map(card => (
                <div key={card.title} className="flex items-center bg-slate-50 p-4 rounded-lg border-l-4 border-[#F39C12] shadow-md text-left">
                    <div className="text-[2.5rem] text-[#F39C12] mr-4">{card.icon}</div>
                    <div className="card-text">
                        <h3 className="text-base font-semibold mb-1 text-[#2c3e50]">{card.title}</h3>
                        <p className="text-[0.85rem] leading-snug text-[#34495e]">{card.description}</p>
                    </div>
                </div>
            ))}
        </div>
      </>
    ),
  },
  {
    id: 'slide-4',
    content: (
      <>
        <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">Áreas de Desempeño: ¿Cuál es tu Pasión?</h2>
        <div className="flex flex-col gap-4 w-full max-w-3xl text-left">
            {[
                { title: 'Farmacia Clínica', description: 'Optimiza la farmacoterapia en piso. Incluye Dosis Unitaria y Farmacovigilancia.' },
                { title: 'Seguimiento Farmacoterapéutico', description: 'Servicio personalizado a pacientes para maximizar la efectividad y adherencia.' },
                { title: 'Farmacotecnia', description: 'Elaboración de fórmulas magistrales, nutrición parenteral y mezclas estériles.' },
                { title: 'Almacén Especializado', description: 'Gestión logística, control de inventarios, cadena de frío y distribución interna.' },
                { title: 'Farmacia Ambulatoria', description: 'Atención y dispensación a pacientes de consulta externa con educación sanitaria.' },
            ].map(area => (
                <div key={area.title} className="flex flex-col sm:flex-row items-start sm:items-center bg-slate-50 p-4 rounded-lg shadow-sm">
                    <strong className="text-[#2c3e50] bg-slate-200 py-2 px-3 rounded-md sm:mr-5 text-base font-semibold sm:min-w-[220px] sm:text-right mb-2 sm:mb-0">{area.title}</strong>
                    <p className="text-base m-0 flex-1 text-[#34495e]">{area.description}</p>
                </div>
            ))}
        </div>
      </>
    ),
  },
  {
    id: 'slide-5',
    content: (
      <>
        <h2 className="text-[2rem] text-[#2c3e50] mb-2 font-semibold">Hablemos de Números: Proyección Salarial 2024</h2>
        <p className="text-[0.9rem] text-[#34495e] mb-5 max-w-3xl">Sueldos brutos mensuales estimados. Varían según institución, experiencia y especialización.</p>
        <div className="flex flex-col gap-3 w-full max-w-2xl text-[0.9rem]">
            {[
                { label: 'Junior / Post-SERUMS', value: 'S/ 3,500 - S/ 4,500', width: '50%' },
                { label: 'Clínica Privada (Inicial)', value: 'S/ 3,800 - S/ 5,000', width: '60%' },
                { label: 'EsSalud (Nombrado)', value: 'S/ 4,500 - S/ 6,500+', width: '75%' },
                { label: 'QF con Especialidad', value: 'S/ 5,500 - S/ 8,000+', width: '90%' },
                { label: 'Jefe / Director Técnico', value: 'S/ 7,000 - S/ 12,000+', width: '100%' },
            ].map(salary => (
                <div key={salary.label} className="flex items-center gap-2.5">
                    <span className="w-[180px] sm:w-[220px] text-right font-semibold text-[#34495e]">{salary.label}</span>
                    <div className="h-7 bg-gradient-to-r from-[#F39C12] to-[#f1c40f] rounded-md text-white flex items-center justify-end pr-4 font-bold shadow-md flex-grow" style={{ width: salary.width }}>
                        {salary.value}
                    </div>
                </div>
            ))}
        </div>
      </>
    ),
  },
  {
    id: 'slide-6',
    content: (
      <>
        <div className="text-5xl mb-4 text-[#F39C12]">🎯</div>
        <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">Visión Estratégica: El "Hospital Líquido"</h2>
        <p className="text-lg text-[#34495e] leading-relaxed max-w-3xl">Reflexionemos sobre la transformación de la farmacia hospitalaria en un sistema de salud dinámico, digitalizado y centrado en el paciente, donde no existen barreras rígidas y fluye la información, las decisiones y los medicamentos.</p>
      </>
    ),
  },
  {
    id: 'slide-7',
    content: (
      <>
        <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">1. La Transformación del Rol Farmacéutico</h2>
        <div className="flex flex-col gap-4 w-full max-w-3xl text-left mt-5">
            {[
                { title: 'De lo Operativo a lo Clínico-Asistencial', description: 'Asumimos una función activa en la toma de decisiones terapéuticas, no solo en la logística.' },
                { title: 'Participación Multidisciplinaria', description: 'Nos integramos en comités clínicos y rondas médicas como garantes del uso racional del medicamento.' },
                { title: 'Enfoque Centrado en el Paciente', description: 'Personalizamos tratamientos, evaluamos interacciones y promovemos el uso seguro en todos los niveles.' },
            ].map(point => (
                <div key={point.title} className="bg-[#F39C12]/5 border-l-4 border-[#F39C12] p-4 rounded-md">
                    <h3 className="text-lg mb-1 text-[#2c3e50] font-semibold">{point.title}</h3>
                    <p className="text-[0.95rem] m-0 leading-normal text-[#34495e]">{point.description}</p>
                </div>
            ))}
        </div>
      </>
    ),
  },
  {
    id: 'slide-8',
    content: (
        <>
            <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">2. Innovación y Tecnología Clave</h2>
            <div className="flex flex-col gap-4 w-full max-w-3xl text-left mt-5">
                {[
                    { title: 'Automatización y Digitalización', description: 'Robots de dispensación, historias clínicas electrónicas y validación remota mejoran la precisión y trazabilidad.' },
                    { title: 'Impacto en Seguridad y Eficiencia', description: 'Disminuyen los errores de medicación, se reducen tiempos de espera y se optimiza el control de inventarios.' },
                ].map(point => (
                    <div key={point.title} className="bg-[#F39C12]/5 border-l-4 border-[#F39C12] p-4 rounded-md">
                        <h3 className="text-lg mb-1 text-[#2c3e50] font-semibold">{point.title}</h3>
                        <p className="text-[0.95rem] m-0 leading-normal text-[#34495e]">{point.description}</p>
                    </div>
                ))}
                <p className="text-center font-semibold text-[#F39C12] mt-4 text-lg">La tecnología nos libera para centrarnos en el rol clínico.</p>
            </div>
        </>
    ),
  },
  {
    id: 'slide-9',
    content: (
        <>
            <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">3. Nuevas Competencias Profesionales</h2>
            <div className="flex flex-col gap-4 w-full max-w-3xl text-left mt-5">
                {[
                    { title: 'Gestión del Riesgo Clínico', description: 'Identificamos eventos adversos y participamos activamente en comités de seguridad del paciente.' },
                    { title: 'Evaluación de Tecnologías Sanitarias (ETS)', description: 'Aportamos evidencia sobre la eficacia, seguridad y costo-beneficio de nuevas terapias.' },
                    { title: 'Educación y Comunicación', description: 'Desarrollamos habilidades para interactuar con pacientes, cuidadores y todo el equipo de salud.' },
                ].map(point => (
                    <div key={point.title} className="bg-[#F39C12]/5 border-l-4 border-[#F39C12] p-4 rounded-md">
                        <h3 className="text-lg mb-1 text-[#2c3e50] font-semibold">{point.title}</h3>
                        <p className="text-[0.95rem] m-0 leading-normal text-[#34495e]">{point.description}</p>
                    </div>
                ))}
            </div>
        </>
    ),
  },
  {
    id: 'slide-10',
    content: (
        <>
            <h2 className="text-[2rem] text-[#2c3e50] mb-6 font-semibold">Conclusión: Un Actor Estratégico</h2>
            <ul className="list-none p-0 text-lg text-[#34495e] leading-relaxed max-w-3xl">
                <li className="py-2.5">Contribuimos a la <strong className="font-semibold text-[#2c3e50]">seguridad del paciente</strong> y a la <strong className="font-semibold text-[#2c3e50]">sostenibilidad</strong> del sistema.</li>
                <li className="py-2.5">Requerimos una combinación de competencias <strong className="font-semibold text-[#2c3e50]">clínicas, tecnológicas y comunicativas</strong>.</li>
            </ul>
            <div className="mt-7 p-5 bg-[#2c3e50] text-white rounded-lg text-center max-w-[90%] sm:max-w-2xl">
                <p className="italic text-lg mb-2.5">"No se trata solo de cambiar la forma en que trabajamos, sino de redefinir el lugar que ocupamos en el proceso asistencial."</p>
                <p className="font-bold text-[#F39C12]">— Prof. José Luis Poveda</p>
            </div>
        </>
    ),
  },
  {
    id: 'slide-11',
    content: (
        <>
            <h2 className="text-[2rem] text-[#2c3e50] mb-8 font-semibold">Construye tu Futuro: Línea de Carrera</h2>
            <div className="flex flex-col md:flex-row justify-between w-full max-w-5xl mt-7 gap-4 md:gap-2.5">
                {[
                    { title: '1. Punto de Partida', description: 'Titulado, Colegiado y Habilitado. Realización del SERUMS es clave para el sector público.' },
                    { title: '2. Especialización', description: 'Segunda Especialidad (Residentado). ¡La clave para diferenciarte y acceder a mejores salarios!' },
                    { title: '3. Crecimiento Vertical', description: 'Coordinador de Área o Especialista Senior. Lidera equipos y conviértete en un referente técnico.' },
                    { title: '4. Cima del Liderazgo', description: 'Jefe de Departamento o Director Técnico. Máxima responsabilidad administrativa y sanitaria.' },
                ].map(step => (
                    <div key={step.title} className="flex-1 p-4 border-t-4 border-[#F39C12] bg-slate-50 rounded-md shadow-sm text-center md:text-left">
                        <h3 className="text-lg text-[#2c3e50] mt-0 mb-2 font-semibold">{step.title}</h3>
                        <p className="text-sm text-[#34495e] leading-relaxed">{step.description}</p>
                    </div>
                ))}
            </div>
        </>
    ),
  },
  {
    id: 'slide-12',
    content: (
        <>
            <h2 className="text-[1.5rem] text-[#34495e] mb-4">Motivación Final</h2>
            <p className="text-[2.2rem] italic font-semibold text-[#2c3e50] max-w-2xl mb-4">"Nunca debes de tener miedo de lo que estas haciendo cuando es correcto"</p>
            <h3 className="text-[#F39C12] text-2xl font-semibold">- Marie Curie</h3>
        </>
    ),
  },
];


function App() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const totalSlides = slidesData.length;

  const handleNext = useCallback(() => {
    setCurrentSlide(prev => (prev < totalSlides - 1 ? prev + 1 : prev));
  }, [totalSlides]);

  const handlePrev = useCallback(() => {
    setCurrentSlide(prev => (prev > 0 ? prev - 1 : prev));
  }, []);

  return (
    <div className="bg-[#f4f6f9] flex justify-center items-center min-h-screen overflow-hidden font-['Poppins'] p-4 sm:p-0">
      <div className="w-full sm:w-[90vw] max-w-[1100px] h-auto sm:h-[60vh] min-h-[400px] sm:max-h-[620px] aspect-[16/9] bg-white shadow-xl rounded-lg relative overflow-hidden flex flex-col">
        <div className="flex-grow relative"> {/* This container will hold the slides */}
          {slidesData.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute top-0 left-0 w-full h-full p-6 sm:p-10 md:px-16 md:py-10 box-border flex flex-col justify-start items-center text-center transition-opacity duration-700 ease-in-out bg-cover bg-center overflow-y-auto ${index === currentSlide ? 'opacity-100 visible' : 'opacity-0 invisible'} ${slide.className || ''}`}
              style={slide.style || {}}
            >
              {slide.content}
            </div>
          ))}
        </div>

        <div className="absolute bottom-6 right-10 z-[5]">
            <img src="https://autonoma.pe/wp-content/uploads/2023/04/logo-autonoma-png-2.png" alt="Logo Universidad Autónoma del Perú" className="h-8 sm:h-10" />
        </div>

        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-4 z-10 p-2">
            <button
                id="prevBtn"
                onClick={handlePrev}
                disabled={currentSlide === 0}
                aria-label="Diapositiva anterior"
                className="py-2.5 px-6 border-none bg-[#2c3e50] text-white rounded-full cursor-pointer text-base transition-all duration-300 hover:bg-[#F39C12] hover:-translate-y-0.5 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:transform-none disabled:hover:bg-gray-400"
            >
                Anterior
            </button>
            <button
                id="nextBtn"
                onClick={handleNext}
                disabled={currentSlide === totalSlides - 1}
                aria-label="Siguiente diapositiva"
                className="py-2.5 px-6 border-none bg-[#2c3e50] text-white rounded-full cursor-pointer text-base transition-all duration-300 hover:bg-[#F39C12] hover:-translate-y-0.5 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:transform-none disabled:hover:bg-gray-400"
            >
                Siguiente
            </button>
        </div>
      </div>
    </div>
  );
}

export default App;
